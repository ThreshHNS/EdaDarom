self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39d88aa9977e32205139ff84476cf80a",
    "url": "./index.html"
  },
  {
    "revision": "48bcd1180b6bf248f45c",
    "url": "./static/css/2.6bab1db4.chunk.css"
  },
  {
    "revision": "b8c15fac28c699450d3e",
    "url": "./static/css/main.ac49c21a.chunk.css"
  },
  {
    "revision": "48bcd1180b6bf248f45c",
    "url": "./static/js/2.f654a12f.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.f654a12f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b8c15fac28c699450d3e",
    "url": "./static/js/main.f140e3cf.chunk.js"
  },
  {
    "revision": "dc3b518d649a1a3ea299",
    "url": "./static/js/runtime-main.263001dc.js"
  },
  {
    "revision": "6d96bdff339b98a3a59198d35109b9c7",
    "url": "./static/media/home.6d96bdff.png"
  },
  {
    "revision": "fb7da079267ddf26601de98ad38d8976",
    "url": "./static/media/person.fb7da079.png"
  },
  {
    "revision": "cb0c15f649d24e6a6552eefa191f828e",
    "url": "./static/media/pizza.cb0c15f6.png"
  },
  {
    "revision": "42c9c8aea154fcc6d828d2e5bc4cddc1",
    "url": "./static/media/product1.42c9c8ae.png"
  },
  {
    "revision": "6cdf3ac57a990545e430546e37e2d1f1",
    "url": "./static/media/product1_fullsize.6cdf3ac5.png"
  },
  {
    "revision": "b828eccb6c35a23df88d015c3b7fec52",
    "url": "./static/media/product2.b828eccb.png"
  },
  {
    "revision": "35eaa0a244194279c020b951bfa22576",
    "url": "./static/media/product3.35eaa0a2.png"
  },
  {
    "revision": "f38ea8382ec911b89888c03a160eb164",
    "url": "./static/media/product4.f38ea838.png"
  },
  {
    "revision": "7dd35ec442e5bcfefcbfccdf2e729463",
    "url": "./static/media/product5.7dd35ec4.png"
  },
  {
    "revision": "fdab6f0485457758cab86bf215843cc3",
    "url": "./static/media/product6.fdab6f04.png"
  },
  {
    "revision": "c486c89787def58cec5bf4cfdcd11f56",
    "url": "./static/media/rating.c486c897.png"
  }
]);