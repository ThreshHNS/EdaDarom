self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7c8aa51efda0ad97368e836ad1c8594b",
    "url": "./index.html"
  },
  {
    "revision": "02254f973ef6b3b5aa94",
    "url": "./static/css/2.6bab1db4.chunk.css"
  },
  {
    "revision": "3bdd0da1ec7002230875",
    "url": "./static/css/main.333aa950.chunk.css"
  },
  {
    "revision": "02254f973ef6b3b5aa94",
    "url": "./static/js/2.a6be27e3.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.a6be27e3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3bdd0da1ec7002230875",
    "url": "./static/js/main.83728e2f.chunk.js"
  },
  {
    "revision": "dc3b518d649a1a3ea299",
    "url": "./static/js/runtime-main.263001dc.js"
  },
  {
    "revision": "6d96bdff339b98a3a59198d35109b9c7",
    "url": "./static/media/home.6d96bdff.png"
  },
  {
    "revision": "fb7da079267ddf26601de98ad38d8976",
    "url": "./static/media/person.fb7da079.png"
  },
  {
    "revision": "cb0c15f649d24e6a6552eefa191f828e",
    "url": "./static/media/pizza.cb0c15f6.png"
  },
  {
    "revision": "c486c89787def58cec5bf4cfdcd11f56",
    "url": "./static/media/rating.c486c897.png"
  }
]);